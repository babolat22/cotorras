package Principal;

import Entidades.Hombre;
import Entidades.Robot;

public class TestJuego {

    public static void main(String[] args) {
        
        Robot tito = new Robot();
        Hombre pibe = new Hombre();
        pibe.jugarConRobot(tito);
        Hombre otroPibe = new Hombre();
        otroPibe.jugarConRobot(tito);
         
    }
    
}
