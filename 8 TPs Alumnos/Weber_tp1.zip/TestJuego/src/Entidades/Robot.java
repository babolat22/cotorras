package Entidades;

public class Robot {
    protected int bateria=1000;
    protected boolean despierto=true;
    
    public void avanzar(int pasos){
        int gasto=pasos*10/100;
        if(despierto && bateria>=gasto){
            bateria-=gasto;
            System.out.println("Amo! =D he avanzado "+pasos+" pasos, tal y como me ha ordenado BEEP BOOP");
        } else if (despierto && bateria<gasto){
            System.out.println("Lo siento, bateria insuficiente amo =(");
        } else {
            System.out.println("ZZZ...");
        }
    }
    
    public void retroceder(int pasos){
        int gasto=pasos*10/100;
        if(despierto && bateria>=gasto){
            bateria-=gasto;
            System.out.println("Amo! =D he retrocedido "+pasos+" pasos, tal y como me ha ordenado BEEP BOOP");
        } else if (despierto && bateria<gasto){
            System.out.println("Lo siento, bateria insuficiente amo =(");
        } else {
            System.out.println("ZZZ...");
        }
    }
    
    public void dormir(){
        despierto=false;
        System.out.println("Recuerde encenderme para poder volver a jugar. ZZZ...");
    }
    
    public void despertar(){
        despierto=true;
        System.out.println("O.O He despertado! Buenos dias/tardes/noches");
    }
    
    public void recargar(){
        bateria=1000;
    }
    
    public boolean bateriaLlena(){
        return bateria==1000;
    }
    
    public boolean bateriaVacia(){
        return bateria==0;
    }
    
    public int bateriaActual(){
        return bateria;
    }

    public boolean isDespierto() {
        return despierto;
    }
    
}
