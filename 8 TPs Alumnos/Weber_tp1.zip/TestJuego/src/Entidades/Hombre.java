package Entidades;
import java.util.Scanner;

public class Hombre {
    protected Scanner pasos = new Scanner(System.in);
    protected int numPasos;
    protected Scanner rta = new Scanner(System.in);
    protected String siOno="no";
    
    //comento el metodo basico y dejo el del extra
    
    /*
    public void jugarConRobot(Robot robot){
        robot.avanzar(500);
        robot.retroceder(20);
        System.out.println("El robot tiene: "+robot.bateriaActual()+" de bateria");
        robot.dormir();
    }
    */
    
    public void jugarConRobot(Robot robot){
        while(siOno.equals("no")||siOno.equals("No")||siOno.equals("NO")){
            
            System.out.println("Cuanto haremos avanzar al robot?");
            numPasos=pasos.nextInt();
            robot.avanzar(numPasos);
            
            System.out.println("Cuanto haremos retroceder al robot?");
            numPasos=pasos.nextInt();
            robot.retroceder(numPasos);
            
            // Solo responder "no", "No" o "NO" hará que se repita el codigo
            System.out.println("Mandamos a dormir al robot? si o no");
            siOno=rta.nextLine();
            
        }
        robot.dormir(); 
    }
}
