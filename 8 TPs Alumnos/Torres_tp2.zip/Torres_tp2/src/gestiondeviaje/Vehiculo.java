package gestiondeviaje;


public abstract class Vehiculo {


    public Vehiculo(){
        
    }
    
    public Vehiculo(String marca, String patente, String combustible) {
    }

    public double CalculoCostoCombustible(double distancia,double precio) {  
        
        return 0;
    }

}