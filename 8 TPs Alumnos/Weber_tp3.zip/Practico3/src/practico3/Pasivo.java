package practico3;

public interface Pasivo {
    
    public void hacerAportes();
    
}
