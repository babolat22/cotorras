package practico1;

import entidades.*;

public class TestJuego {

    public static void main(String[] args) {
        Robot T800 = new Robot();
        Humano JohnConnor = new Humano();
        JohnConnor.jugarConRobot(T800);
        System.out.println("Ahora Sarah tiene el robot.");
        Humano SarahConnor = new Humano();
        SarahConnor.jugarConRobot(T800);
    }
}
