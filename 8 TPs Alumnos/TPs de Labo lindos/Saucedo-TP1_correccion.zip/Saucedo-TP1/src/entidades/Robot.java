package entidades;

public class Robot {

    private double bateria;
    private boolean dormir;

    public Robot() {
        bateria = 1000;
        dormir = false;
    }

    public void avanzar(int pasos) {
        if (dormir) {
            System.out.println("El robot esta durmiendo.");
        } else if (bateria >= pasos * 0.1) {
            System.out.println("El robot se movio " + pasos + " pasos.");
            bateria -= pasos * 0.1;
        } else {
            System.out.println("No hay suficiente energia.");
        }
    }

    public void retroceder(int pasos) {
        avanzar(pasos);
    }

    public void dormir() {
        if (dormir) {
            System.out.println("El robot ya se encuentra durmiendo.");
        } else {
            dormir = true;
            System.out.println("El robot ahora esta en modo dormir.");
        }
    }

    public void despertar() {
        if (dormir) {
            dormir = false;
            System.out.println("El robot ahora esta en modo despierto.");
        } else {
            System.out.println("El robot ya se encuentra despierto.");
        }
    }

    public void recargar() {
        if (dormir) {
            System.out.println("El robot esta durmiendo");
        } else {
            bateria = 1000;
            System.out.println("La bateria se recargo.");
        }
    }

    public boolean bateriaLlena() {
        return bateria == 1000;
    }

    public boolean bateriaVacia() {
        return bateria == 0;
    }

    public double bateriaActual() {
        return bateria;
    }

    //------------
    
    public double getBateria() {
        return bateria;
    }

    public boolean getDormir() {
        return dormir;
    }
}
