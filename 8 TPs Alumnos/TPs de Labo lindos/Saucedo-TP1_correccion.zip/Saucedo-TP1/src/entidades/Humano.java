package entidades;

import java.util.Scanner;

public class Humano {

    public Humano() {}

    public void jugarConRobot(Robot r) {
        Scanner k = new Scanner(System.in);
        byte i = 1;
        int pasos;
        while (i != 0) {
            System.out.println("Elija una opcion:");
            System.out.println("1.  Avanzar");
            System.out.println("2.  Retroceder");
            System.out.println("3.  Despertar");
            System.out.println("4.  Dormir");
            System.out.println("5.  Recargar batería");
            i = k.nextByte();
            switch (i) {
                case 1: {
                    System.out.println("Introduzca cantidad de pasos:");
                    pasos = k.nextInt();
                    r.avanzar(pasos);
                    System.out.println("Bateria restante:" + r.getBateria());
                    break;
                }
                case 2: {
                    System.out.println("Introduzca cantidad de pasos:");
                    pasos = k.nextInt();
                    r.retroceder(pasos);
                    System.out.println("Bateria restante:" + r.getBateria());
                    break;
                }
                case 3: {
                    r.despertar();
                    break;
                }
                case 4: {
                    i = 0;
                    break;
                }
                case 5: {
                    r.recargar();
                    break;
                }
                default: {
                    System.out.println("Opcion incorrecta.");
                    break;
                }
            }
        }
        r.dormir();
    }
}
